
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable{
	Text gen;
	
	public MyValue(){
		this.gen = new Text();
	}
	public MyValue(Text line){
		this.gen =line;
	};
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		gen.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		gen.write(arg0);
	}
	
	public void setLine(Text line){
		this.gen=line;
	}
	public Text getLine(){
		return gen;
	}

}
